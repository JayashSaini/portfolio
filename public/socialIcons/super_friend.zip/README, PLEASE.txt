This font is for PERSONAL USE ONLY!.

If you want to use this font for commercial purposes, you will need to purchase a commercial license. You can purchase a commercial license at 

https://allsuperfont.com/product/super-friend/

Super Friend Font: A Bold and Retro Aesthetic

The Super Friend font is a captivating typeface that seamlessly blends boldness with nostalgic retro vibes. Its unique design evokes memories of vintage posters, logos, and classic flyers. The Super Friend font invites users to embark on a journey through time, celebrating the bold and vibrant spirit of yesteryears.